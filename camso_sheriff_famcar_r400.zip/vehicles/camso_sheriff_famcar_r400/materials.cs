singleton Material(material_0_sheriff_famcar_r400_sheriff_famcar_r400_body0)
{
	mapTo = "material_0_sheriff_famcar_r400_sheriff_famcar_r400_body0"; 
	opacityMap[0] = "camso_sheriff_famcar_r400_stamp0.dds";
	opacityMapUV[0] = "1";
	opacityMap[1] = "camso_sheriff_famcar_r400_stamp0.dds";
	opacityMapUV[1] = "1";
	diffuseMap[0] = "vehicles/common/null.dds";
	diffuseMap[1] = "vehicles/common/null.dds";
	specularMap[0] = "camso_col_0xff383838.dds";
	specularMap[1] = "camso_col_0xff383838.dds";
	castShadows = "1"; 
	doubleSided = "1"; 
	specularPower[0] = "479.999969";
	specular[0] = "1 1 1 1";
	specularPower[1] = "479.999969";
	specular[1] = "1 1 1 1";
	diffuseColor[0] = "1 1 1 1"; 
	diffuseColor[1] = "1 1 1 0.001"; 
	instanceDiffuse[2] = true;
	specularMap[2] = "camso_col_0xff383838.dds";
	diffuseMap[2] = "vehicles/common/null.dds";
	specularPower[2] = "479.999969";
	specular[2] = "1 1 1 1";
	diffuseColor[2] = "1 1 1 0.5"; 
	opacityMap[2] = "camso_sheriff_famcar_r400_stamp0.dds";
	opacityMapUV[2] = "1";
	useAnisotropic[2] = "1";
	castShadows = "1";
	translucent = "1"; 
	alphaTest = "1"; 
	alphaRef = "128"; 
	translucentZWrite = true; 
	translucentBlendOp = "None";
	dynamicCubemap = true;
	materialTag0 = "beamng"; materialTag2 = "vehicle";
}; 
singleton Material(material_1_sheriff_famcar_r400_sheriff_famcar_r400_body0)
{
	mapTo = "material_1_sheriff_famcar_r400_sheriff_famcar_r400_body0"; 
	opacityMap[0] = "camso_sheriff_famcar_r400_stamp0.dds";
	opacityMapUV[0] = "1";
	diffuseMap[0] = "vehicles/common/null.dds";
	specularMap[0] = "camso_col_0xff383838.dds";
	specularPower[0] = "50.000000";
	castShadows = "1";
	doubleSided = "1"; 
	diffuseColor[0] = "0.0627451 0.0627451 0.0627451 1"; 
	translucent = "1"; 
	alphaTest = "1"; 
	alphaRef = "128"; 
	translucentZWrite = true; 
	translucentBlendOp = "None";
	materialTag0 = "beamng";
}; 
singleton Material(material_2_sheriff_famcar_r400_sheriff_famcar_r400_body0)
{
	mapTo = "material_2_sheriff_famcar_r400_sheriff_famcar_r400_body0"; 
	opacityMap[0] = "camso_sheriff_famcar_r400_stamp0.dds";
	opacityMapUV[0] = "1";
	diffuseMap[0] = "vehicles/common/null.dds";
	specularMap[0] = "camso_col_0xff383838.dds";
	specularPower[0] = "50.000000";
	castShadows = "1";
	doubleSided = "1"; 
	diffuseColor[0] = "0.0627451 0.0627451 0.0627451 1"; 
	translucent = "1"; 
	alphaTest = "1"; 
	alphaRef = "128"; 
	translucentZWrite = true; 
	translucentBlendOp = "None";
	materialTag0 = "beamng";
}; 
singleton Material(material_3_sheriff_famcar_r400_sheriff_famcar_r400_body0)
{
	mapTo = "material_3_sheriff_famcar_r400_sheriff_famcar_r400_body0"; 
	diffuseMap[0] = "vehicles/common/null.dds";
	diffuseMap[1] = "vehicles/common/null.dds";
	specularMap[0] = "camso_col_0xff383838.dds";
	specularMap[1] = "camso_col_0xff383838.dds";
	opacityMap[0] = "camso_sheriff_famcar_r400_stamp0.dds";
	opacityMapUV[0] = "1";
	opacityMap[1] = "camso_sheriff_famcar_r400_stamp0.dds";
	opacityMapUV[1] = "1";
	reflectivityMap[0] = "camso_sheriff_famcar_r400_GlassReflectivityMap0.dds";
	reflectivityMapUV[0] = "1"; 
	specularPower[0] = "800.000000"; 
	pixelSpecular[0] = "1"; 
	specularPower[1] = "800.000000"; 
	pixelSpecular[1] = "1"; 
	diffuseColor[0] = "0.00392157 0.101961 0.0862745 1"; 
	diffuseColor[1] = "0.00392157 0.101961 0.0862745 1"; 
	useAnisotropic[0] = "1"; 
	useAnisotropic[1] = "1"; 
	dynamicCubemap = true;
	castShadows = "0"; 
	translucent = "1"; 
	alphaTest = "1"; 
	alphaRef = "0"; 
	translucentZWrite = false; 
	materialTag0 = "beamng";
	materialTag1 = "vehicle";
}; 
singleton Material(material_4_sheriff_famcar_r400_chassis1)
{
	mapTo = "material_4_sheriff_famcar_r400_chassis1"; 
	diffuseMap[0] = "vehicles/common/null.dds";
	specularMap[0] = "camso_col_0xff383838.dds";
	specularPower[0] = "50.000000";
	useAnisotropic[0] = "1"; 
	castShadows = "1"; 
	doubleSided = "1"; 
	diffuseColor[0] = "0.337255 0.337255 0.337255 1"; 
	normalMap[0] = "camso_t_carbonfiber_twill_n.dds"; 
	translucent = "0"; 
	translucentBlendOp = "None";
	alphaTest = "0"; 
	alphaRef = "1"; 
	materialTag0 = "beamng";
}; 
singleton Material(material_5_sheriff_famcar_r400_chassis1)
{
	mapTo = "material_5_sheriff_famcar_r400_chassis1"; 
	diffuseMap[0] = "vehicles/common/null.dds";
	specularMap[0] = "camso_col_0xff2a3c46.dds";
	specularPower[0] = "800.000000";
	diffuseColor[0] = "0.737255 0.737255 0.737255 1"; 
	useAnisotropic[0] = "1"; 
	materialTag0 = "beamng";
	diffuseMap[1] = "vehicles/common/null.dds";
	specularMap[1] = "camso_col_0xff000000.dds";
	specularPower[1] = "10.000000";
	diffuseColor[1] = "0.737255 0.737255 0.737255 1"; 
	useAnisotropic[1] = "1"; 
	materialTag1 = "vehicle";
	castShadows = "1";
	dynamicCubemap = true;
	doubleSided = "1"; 
	translucent = "0"; 
	translucentBlendOp = "None";
	alphaTest = "0"; 
	alphaRef = "1"; 
}; 
singleton Material(material_6_sheriff_famcar_r400_temp2)
{
	mapTo = "material_6_sheriff_famcar_r400_temp2"; 
	diffuseMap[0] = "vehicles/common/null.dds";
	specularMap[0] = "camso_col_0xff2a3c46.dds";
	specularPower[0] = "800.000000";
	diffuseColor[0] = "0.737255 0.737255 0.737255 1"; 
	useAnisotropic[0] = "1"; 
	materialTag0 = "beamng";
	diffuseMap[1] = "vehicles/common/null.dds";
	specularMap[1] = "camso_col_0xff000000.dds";
	specularPower[1] = "10.000000";
	diffuseColor[1] = "0.737255 0.737255 0.737255 1"; 
	useAnisotropic[1] = "1"; 
	materialTag1 = "vehicle";
	castShadows = "1";
	dynamicCubemap = true;
	doubleSided = "1"; 
	translucent = "0"; 
	translucentBlendOp = "None";
	alphaTest = "0"; 
	alphaRef = "1"; 
}; 
singleton Material(material_7_sheriff_famcar_r400_tyre_f2)
{
	mapTo = "material_7_sheriff_famcar_r400_tyre_f2"; 
	diffuseMap[0] = "vehicles/common/null.dds";
	specularMap[0] = "camso_col_0xff383838.dds";
	specularPower[0] = "50.000000";
	useAnisotropic[0] = "1"; 
	castShadows = "1"; 
	doubleSided = "0"; 
	diffuseColor[0] = "0.12549 0.12549 0.12549 1"; 
	normalMap[0] = "camso_tyresemi_tread_normal.dds"; 
	translucent = "0"; 
	translucentBlendOp = "None";
	alphaTest = "0"; 
	alphaRef = "1"; 
	materialTag0 = "beamng";
}; 
singleton Material(material_8_sheriff_famcar_r400_tyre_f2)
{
	mapTo = "material_8_sheriff_famcar_r400_tyre_f2"; 
	diffuseMap[0] = "vehicles/common/null.dds";
	specularMap[0] = "camso_col_0xff383838.dds";
	specularPower[0] = "50.000000";
	useAnisotropic[0] = "1"; 
	castShadows = "1"; 
	doubleSided = "0"; 
	diffuseColor[0] = "0.12549 0.12549 0.12549 1"; 
	normalMap[0] = "camso_tyresemi_sidewall_normal.dds"; 
	translucent = "0"; 
	translucentBlendOp = "None";
	alphaTest = "0"; 
	alphaRef = "1"; 
	materialTag0 = "beamng";
}; 
singleton Material(material_9_sheriff_famcar_r400_tyre_f2)
{
	mapTo = "material_9_sheriff_famcar_r400_tyre_f2"; 
	diffuseMap[0] = "vehicles/common/null.dds";
	diffuseMap[1] = "vehicles/common/null.dds";
	specularMap[0] = "camso_col_0xff383838.dds";
	specularMap[1] = "camso_col_0xff383838.dds";
	castShadows = "1"; 
	doubleSided = "1"; 
	specularPower[0] = "80.000000";
	specular[0] = "1 1 1 1";
	specularPower[1] = "80.000000";
	specular[1] = "1 1 1 1";
	diffuseColor[0] = "0 0 0 1"; 
	diffuseColor[1] = "0 0 0 0.904"; 
	castShadows = "1";
	translucent = "0"; 
	translucentBlendOp = "None";
	alphaTest = "0"; 
	alphaRef = "1"; 
	dynamicCubemap = true;
	materialTag0 = "beamng"; materialTag2 = "vehicle";
}; 
singleton Material(material_10_sheriff_famcar_r400_wheel_f3)
{
	mapTo = "material_10_sheriff_famcar_r400_wheel_f3"; 
	diffuseMap[0] = "vehicles/common/null.dds";
	diffuseMap[1] = "vehicles/common/null.dds";
	specularMap[0] = "camso_col_0xff383838.dds";
	specularMap[1] = "camso_col_0xff383838.dds";
	castShadows = "1"; 
	doubleSided = "1"; 
	specularPower[0] = "80.000000";
	specular[0] = "1 1 1 1";
	specularPower[1] = "80.000000";
	specular[1] = "1 1 1 1";
	diffuseColor[0] = "0 0 0 1"; 
	diffuseColor[1] = "0 0 0 0.904"; 
	castShadows = "1";
	translucent = "0"; 
	translucentBlendOp = "None";
	alphaTest = "0"; 
	alphaRef = "1"; 
	dynamicCubemap = true;
	materialTag0 = "beamng"; materialTag2 = "vehicle";
}; 
singleton Material(material_11_sheriff_famcar_r400_suspension_f4)
{
	mapTo = "material_11_sheriff_famcar_r400_suspension_f4"; 
	diffuseMap[0] = "vehicles/common/null.dds";
	specularMap[0] = "camso_col_0xff2a3c46.dds";
	specularPower[0] = "800.000000";
	diffuseColor[0] = "0.596078 0.596078 0.596078 1"; 
	useAnisotropic[0] = "1"; 
	materialTag0 = "beamng";
	diffuseMap[1] = "vehicles/common/null.dds";
	specularMap[1] = "camso_col_0xff000000.dds";
	specularPower[1] = "10.000000";
	diffuseColor[1] = "0.596078 0.596078 0.596078 1"; 
	useAnisotropic[1] = "1"; 
	materialTag1 = "vehicle";
	castShadows = "1";
	dynamicCubemap = true;
	doubleSided = "1"; 
	translucent = "0"; 
	translucentBlendOp = "None";
	alphaTest = "0"; 
	alphaRef = "1"; 
}; 
singleton Material(material_12_sheriff_famcar_r400_suspension_f4)
{
	mapTo = "material_12_sheriff_famcar_r400_suspension_f4"; 
	diffuseMap[0] = "vehicles/common/null.dds";
	specularMap[0] = "camso_col_0xff383838.dds";
	specularPower[0] = "50.000000";
	useAnisotropic[0] = "1"; 
	castShadows = "1"; 
	doubleSided = "0"; 
	diffuseColor[0] = "0.0470588 0.0470588 0.0470588 1"; 
	translucent = "0"; 
	translucentBlendOp = "None";
	alphaTest = "0"; 
	alphaRef = "1"; 
	materialTag0 = "beamng";
}; 
singleton Material(material_13_sheriff_famcar_r400_suspension_f4)
{
	mapTo = "material_13_sheriff_famcar_r400_suspension_f4"; 
	diffuseMap[0] = "vehicles/common/null.dds";
	specularMap[0] = "camso_col_0xff383838.dds";
	specularPower[0] = "50.000000";
	useAnisotropic[0] = "1"; 
	castShadows = "1"; 
	doubleSided = "1"; 
	diffuseColor[0] = "0.662745 0.568627 0.113725 1"; 
	translucent = "0"; 
	translucentBlendOp = "None";
	alphaTest = "0"; 
	alphaRef = "1"; 
	materialTag0 = "beamng";
}; 
singleton Material(material_14_sheriff_famcar_r400_suspension_f4)
{
	mapTo = "material_14_sheriff_famcar_r400_suspension_f4"; 
	diffuseMap[0] = "vehicles/common/null.dds";
	specularMap[0] = "camso_col_0xff383838.dds";
	specularPower[0] = "50.000000";
	useAnisotropic[0] = "1"; 
	castShadows = "1"; 
	doubleSided = "1"; 
	diffuseColor[0] = "0.517647 0 0 1"; 
	translucent = "0"; 
	translucentBlendOp = "None";
	alphaTest = "0"; 
	alphaRef = "1"; 
	materialTag0 = "beamng";
}; 
singleton Material(material_15_sheriff_famcar_r400_brakecaliper_f5)
{
	mapTo = "material_15_sheriff_famcar_r400_brakecaliper_f5"; 
	diffuseMap[0] = "vehicles/common/null.dds";
	diffuseMap[1] = "vehicles/common/null.dds";
	specularMap[0] = "camso_col_0xff383838.dds";
	specularMap[1] = "camso_col_0xff383838.dds";
	castShadows = "1"; 
	doubleSided = "1"; 
	specularPower[0] = "800.000000";
	specular[0] = "1 1 1 1";
	specularPower[1] = "800.000000";
	specular[1] = "1 1 1 1";
	diffuseColor[0] = "0.807843 0 0 1"; 
	diffuseColor[1] = "0.807843 0 0 0.4"; 
	castShadows = "1";
	translucent = "0"; 
	translucentBlendOp = "None";
	alphaTest = "0"; 
	alphaRef = "1"; 
	dynamicCubemap = true;
	materialTag0 = "beamng"; materialTag2 = "vehicle";
}; 
singleton Material(material_16_sheriff_famcar_r400_brakecaliper_f5)
{
	mapTo = "material_16_sheriff_famcar_r400_brakecaliper_f5"; 
	diffuseMap[0] = "vehicles/common/null.dds";
	specularMap[0] = "camso_col_0xff383838.dds";
	specularPower[0] = "50.000000";
	useAnisotropic[0] = "1"; 
	castShadows = "1"; 
	doubleSided = "0"; 
	diffuseColor[0] = "0.0470588 0.0470588 0.0470588 1"; 
	translucent = "0"; 
	translucentBlendOp = "None";
	alphaTest = "0"; 
	alphaRef = "1"; 
	materialTag0 = "beamng";
}; 
singleton Material(material_17_sheriff_famcar_r400_brakecaliper_f5)
{
	mapTo = "material_17_sheriff_famcar_r400_brakecaliper_f5"; 
	diffuseMap[0] = "vehicles/common/null.dds";
	specularMap[0] = "camso_col_0xff2a2a2a.dds";
	specularPower[0] = "800.000000";
	diffuseColor[0] = "0.709804 0.670588 0.611765 1"; 
	normalMap[0] = "camso_boltnormal.dds"; 
	useAnisotropic[0] = "1"; 
	materialTag0 = "beamng";
	diffuseMap[1] = "vehicles/common/null.dds";
	specularMap[1] = "camso_col_0xff000000.dds";
	specularPower[1] = "10.000000";
	diffuseColor[1] = "0.709804 0.670588 0.611765 1"; 
	normalMap[1] = "camso_boltnormal.dds"; 
	useAnisotropic[1] = "1"; 
	materialTag1 = "vehicle";
	castShadows = "1";
	dynamicCubemap = true;
	doubleSided = "1"; 
	translucent = "0"; 
	translucentBlendOp = "None";
	alphaTest = "0"; 
	alphaRef = "1"; 
}; 
singleton Material(material_18_sheriff_famcar_r400_temp6)
{
	mapTo = "material_18_sheriff_famcar_r400_temp6"; 
	diffuseMap[0] = "vehicles/common/null.dds";
	specularMap[0] = "camso_col_0xff2a3c46.dds";
	specularPower[0] = "800.000000";
	diffuseColor[0] = "0.372549 0.372549 0.372549 1"; 
	useAnisotropic[0] = "1"; 
	materialTag0 = "beamng";
	diffuseMap[1] = "vehicles/common/null.dds";
	specularMap[1] = "camso_col_0xff000000.dds";
	specularPower[1] = "10.000000";
	diffuseColor[1] = "0.372549 0.372549 0.372549 1"; 
	useAnisotropic[1] = "1"; 
	materialTag1 = "vehicle";
	castShadows = "1";
	dynamicCubemap = true;
	doubleSided = "1"; 
	translucent = "0"; 
	translucentBlendOp = "None";
	alphaTest = "0"; 
	alphaRef = "1"; 
}; 
singleton Material(material_19_sheriff_famcar_r400_temp6)
{
	mapTo = "material_19_sheriff_famcar_r400_temp6"; 
	diffuseMap[0] = "vehicles/common/null.dds";
	specularMap[0] = "camso_col_0xff2a3c46.dds";
	specularPower[0] = "800.000000";
	diffuseColor[0] = "0.737255 0.737255 0.737255 1"; 
	useAnisotropic[0] = "1"; 
	materialTag0 = "beamng";
	diffuseMap[1] = "vehicles/common/null.dds";
	specularMap[1] = "camso_col_0xff000000.dds";
	specularPower[1] = "10.000000";
	diffuseColor[1] = "0.737255 0.737255 0.737255 1"; 
	useAnisotropic[1] = "1"; 
	materialTag1 = "vehicle";
	castShadows = "1";
	dynamicCubemap = true;
	doubleSided = "1"; 
	translucent = "0"; 
	translucentBlendOp = "None";
	alphaTest = "0"; 
	alphaRef = "1"; 
}; 
singleton Material(material_20_sheriff_famcar_r400_temp6)
{
	mapTo = "material_20_sheriff_famcar_r400_temp6"; 
	diffuseMap[0] = "vehicles/common/null.dds";
	specularMap[0] = "camso_col_0xff2a2a2a.dds";
	specularPower[0] = "800.000000";
	diffuseColor[0] = "0.94902 0.854902 0.639216 1"; 
	useAnisotropic[0] = "1"; 
	materialTag0 = "beamng";
	diffuseMap[1] = "vehicles/common/null.dds";
	specularMap[1] = "camso_col_0xff000000.dds";
	specularPower[1] = "10.000000";
	diffuseColor[1] = "0.94902 0.854902 0.639216 0.8"; 
	useAnisotropic[1] = "1"; 
	materialTag1 = "vehicle";
	castShadows = "1";
	dynamicCubemap = true;
	doubleSided = "1"; 
	translucent = "0"; 
	translucentBlendOp = "None";
	alphaTest = "0"; 
	alphaRef = "1"; 
}; 
singleton Material(material_21_sheriff_famcar_r400_efixturetype__eft_wing012)
{
	mapTo = "material_21_sheriff_famcar_r400_efixturetype__eft_wing012"; 
	diffuseMap[0] = "vehicles/common/null.dds";
	diffuseMap[1] = "vehicles/common/null.dds";
	specularMap[0] = "camso_col_0xff383838.dds";
	specularMap[1] = "camso_col_0xff383838.dds";
	castShadows = "1"; 
	doubleSided = "1"; 
	specularPower[0] = "479.999969";
	specular[0] = "1 1 1 1";
	specularPower[1] = "479.999969";
	specular[1] = "1 1 1 1";
	diffuseColor[0] = "1 1 1 1"; 
	diffuseColor[1] = "1 1 1 0.001"; 
	instanceDiffuse[2] = true;
	specularMap[2] = "camso_col_0xff383838.dds";
	diffuseMap[2] = "vehicles/common/null.dds";
	specularPower[2] = "479.999969";
	specular[2] = "1 1 1 1";
	diffuseColor[2] = "1 1 1 0.5"; 
	castShadows = "1";
	translucent = "0"; 
	translucentBlendOp = "None";
	alphaTest = "0"; 
	alphaRef = "1"; 
	dynamicCubemap = true;
	materialTag0 = "beamng"; materialTag2 = "vehicle";
}; 
singleton Material(material_22_sheriff_famcar_r400_efixturetype__eft_wing012)
{
	mapTo = "material_22_sheriff_famcar_r400_efixturetype__eft_wing012"; 
	diffuseMap[0] = "vehicles/common/null.dds";
	specularMap[0] = "camso_col_0xff383838.dds";
	specularPower[0] = "50.000000";
	useAnisotropic[0] = "1"; 
	castShadows = "1"; 
	doubleSided = "1"; 
	diffuseColor[0] = "1 1 1 1"; 
	translucent = "0"; 
	translucentBlendOp = "None";
	alphaTest = "0"; 
	alphaRef = "1"; 
	materialTag0 = "beamng";
}; 
singleton Material(material_23_sheriff_famcar_r400_temp13)
{
	mapTo = "material_23_sheriff_famcar_r400_temp13"; 
	diffuseMap[0] = "vehicles/common/null.dds";
	specularMap[0] = "camso_col_0xff383838.dds";
	specularPower[0] = "50.000000";
	castShadows = "1";
	doubleSided = "1"; 
	diffuseColor[0] = "0.168627 0.168627 0.168627 1"; 
	translucent = "0"; 
	translucentBlendOp = "None";
	alphaTest = "0"; 
	alphaRef = "1"; 
	materialTag0 = "beamng";
}; 
singleton Material(material_24_sheriff_famcar_r400_efixturetype__eft_lip013)
{
	mapTo = "material_24_sheriff_famcar_r400_efixturetype__eft_lip013"; 
	diffuseMap[0] = "vehicles/common/null.dds";
	specularMap[0] = "camso_col_0xff383838.dds";
	specularPower[0] = "50.000000";
	castShadows = "1";
	doubleSided = "1"; 
	diffuseColor[0] = "0.168627 0.168627 0.168627 1"; 
	translucent = "0"; 
	translucentBlendOp = "None";
	alphaTest = "0"; 
	alphaRef = "1"; 
	materialTag0 = "beamng";
}; 
singleton Material(material_25_sheriff_famcar_r400_inl_dohc_5_mid_c_2144165635_sectionmesh_inlv_dohc_5_head_mid14)
{
	mapTo = "material_25_sheriff_famcar_r400_inl_dohc_5_mid_c_2144165635_sectionmesh_inlv_dohc_5_head_mid14"; 
	diffuseMap[0] = "vehicles/common/null.dds";
	specularMap[0] = "camso_col_0xff2a2a2a.dds";
	specularPower[0] = "800.000000";
	diffuseColor[0] = "0.866667 0.878431 0.905882 1"; 
	useAnisotropic[0] = "1"; 
	materialTag0 = "beamng";
	diffuseMap[1] = "vehicles/common/null.dds";
	specularMap[1] = "camso_col_0xff000000.dds";
	specularPower[1] = "10.000000";
	diffuseColor[1] = "0.866667 0.878431 0.905882 1"; 
	useAnisotropic[1] = "1"; 
	materialTag1 = "vehicle";
	castShadows = "1";
	dynamicCubemap = true;
	doubleSided = "1"; 
	translucent = "0"; 
	translucentBlendOp = "None";
	alphaTest = "0"; 
	alphaRef = "1"; 
}; 
singleton Material(material_26_sheriff_famcar_r400_inl_dohc_5_mid_c_2144165635_sectionmesh_inlv_dohc_5_head_mid14)
{
	mapTo = "material_26_sheriff_famcar_r400_inl_dohc_5_mid_c_2144165635_sectionmesh_inlv_dohc_5_head_mid14"; 
	diffuseMap[0] = "vehicles/common/null.dds";
	specularMap[0] = "camso_col_0xff383838.dds";
	specularPower[0] = "50.000000";
	useAnisotropic[0] = "1"; 
	castShadows = "1"; 
	doubleSided = "1"; 
	diffuseColor[0] = "1 1 1 1"; 
	normalMap[0] = "camso_headfacingnormal.dds"; 
	translucent = "0"; 
	translucentBlendOp = "None";
	alphaTest = "0"; 
	alphaRef = "1"; 
	materialTag0 = "beamng";
}; 
singleton Material(material_27_sheriff_famcar_r400_inl_dohc_5_mid_c_2144165635_sectionmesh_inlv_dohc_5_head_mid14)
{
	mapTo = "material_27_sheriff_famcar_r400_inl_dohc_5_mid_c_2144165635_sectionmesh_inlv_dohc_5_head_mid14"; 
	diffuseMap[0] = "vehicles/common/null.dds";
	specularMap[0] = "camso_col_0xff2a3c46.dds";
	specularPower[0] = "800.000000";
	diffuseColor[0] = "0.737255 0.737255 0.737255 1"; 
	useAnisotropic[0] = "1"; 
	materialTag0 = "beamng";
	diffuseMap[1] = "vehicles/common/null.dds";
	specularMap[1] = "camso_col_0xff000000.dds";
	specularPower[1] = "10.000000";
	diffuseColor[1] = "0.737255 0.737255 0.737255 1"; 
	useAnisotropic[1] = "1"; 
	materialTag1 = "vehicle";
	castShadows = "1";
	dynamicCubemap = true;
	doubleSided = "1"; 
	translucent = "0"; 
	translucentBlendOp = "None";
	alphaTest = "0"; 
	alphaRef = "1"; 
}; 
singleton Material(material_28_sheriff_famcar_r400_inl_dohc_5_mid_c_2144165635_sectionmesh_inlv_dohc_5_head_mid14)
{
	mapTo = "material_28_sheriff_famcar_r400_inl_dohc_5_mid_c_2144165635_sectionmesh_inlv_dohc_5_head_mid14"; 
	diffuseMap[0] = "vehicles/common/null.dds";
	specularMap[0] = "camso_col_0xff2a3c46.dds";
	specularPower[0] = "800.000000";
	diffuseColor[0] = "0.6 0.6 0.6 1"; 
	useAnisotropic[0] = "1"; 
	materialTag0 = "beamng";
	diffuseMap[1] = "vehicles/common/null.dds";
	specularMap[1] = "camso_col_0xff000000.dds";
	specularPower[1] = "10.000000";
	diffuseColor[1] = "0.6 0.6 0.6 1"; 
	useAnisotropic[1] = "1"; 
	materialTag1 = "vehicle";
	castShadows = "1";
	dynamicCubemap = true;
	doubleSided = "1"; 
	translucent = "0"; 
	translucentBlendOp = "None";
	alphaTest = "0"; 
	alphaRef = "1"; 
}; 
singleton Material(material_29_sheriff_famcar_r400_inl_dohc_5_mid_c_2144165635_sectionmesh_inlv_dohc_5_head_mid14)
{
	mapTo = "material_29_sheriff_famcar_r400_inl_dohc_5_mid_c_2144165635_sectionmesh_inlv_dohc_5_head_mid14"; 
	diffuseMap[0] = "vehicles/common/null.dds";
	specularMap[0] = "camso_col_0xff2a2a2a.dds";
	specularPower[0] = "800.000000";
	diffuseColor[0] = "0.94902 0.854902 0.639216 1"; 
	useAnisotropic[0] = "1"; 
	materialTag0 = "beamng";
	diffuseMap[1] = "vehicles/common/null.dds";
	specularMap[1] = "camso_col_0xff000000.dds";
	specularPower[1] = "10.000000";
	diffuseColor[1] = "0.94902 0.854902 0.639216 0.8"; 
	useAnisotropic[1] = "1"; 
	materialTag1 = "vehicle";
	castShadows = "1";
	dynamicCubemap = true;
	doubleSided = "1"; 
	translucent = "0"; 
	translucentBlendOp = "None";
	alphaTest = "0"; 
	alphaRef = "1"; 
}; 
singleton Material(material_30_sheriff_famcar_r400_inl_dohc_5_mid_c_2144165635_sectionmesh_inlv_dohc_5_head_mid14)
{
	mapTo = "material_30_sheriff_famcar_r400_inl_dohc_5_mid_c_2144165635_sectionmesh_inlv_dohc_5_head_mid14"; 
	diffuseMap[0] = "vehicles/common/null.dds";
	specularMap[0] = "camso_col_0xff383838.dds";
	specularPower[0] = "50.000000";
	useAnisotropic[0] = "1"; 
	castShadows = "1"; 
	doubleSided = "0"; 
	diffuseColor[0] = "0.0470588 0.0470588 0.0470588 1"; 
	translucent = "0"; 
	translucentBlendOp = "None";
	alphaTest = "0"; 
	alphaRef = "1"; 
	materialTag0 = "beamng";
}; 
singleton Material(material_31_sheriff_famcar_r400_inl_dohc_4_rockercover_frontmid_c_2144165632_staticmesh_inlv_dohc_4_rockercover_mid15)
{
	mapTo = "material_31_sheriff_famcar_r400_inl_dohc_4_rockercover_frontmid_c_2144165632_staticmesh_inlv_dohc_4_rockercover_mid15"; 
	diffuseMap[0] = "vehicles/common/null.dds";
	specularMap[0] = "camso_col_0xff2a2a2a.dds";
	specularPower[0] = "800.000000";
	diffuseColor[0] = "0.603922 0.603922 0.623529 1"; 
	useAnisotropic[0] = "1"; 
	materialTag0 = "beamng";
	diffuseMap[1] = "vehicles/common/null.dds";
	specularMap[1] = "camso_col_0xff000000.dds";
	specularPower[1] = "10.000000";
	diffuseColor[1] = "0.603922 0.603922 0.623529 1"; 
	useAnisotropic[1] = "1"; 
	materialTag1 = "vehicle";
	castShadows = "1";
	dynamicCubemap = true;
	doubleSided = "1"; 
	translucent = "0"; 
	translucentBlendOp = "None";
	alphaTest = "0"; 
	alphaRef = "1"; 
}; 
singleton Material(material_32_sheriff_famcar_r400_crankshaftbuilder_c_2144213223_node_addstaticmeshcomponent_10_crank_main_shaft34)
{
	mapTo = "material_32_sheriff_famcar_r400_crankshaftbuilder_c_2144213223_node_addstaticmeshcomponent_10_crank_main_shaft34"; 
	diffuseMap[0] = "vehicles/common/null.dds";
	specularMap[0] = "camso_col_0xff2a2a2a.dds";
	specularPower[0] = "800.000000";
	diffuseColor[0] = "0.913725 0.984314 1 1"; 
	useAnisotropic[0] = "1"; 
	materialTag0 = "beamng";
	diffuseMap[1] = "vehicles/common/null.dds";
	specularMap[1] = "camso_col_0xff000000.dds";
	specularPower[1] = "10.000000";
	diffuseColor[1] = "0.913725 0.984314 1 0.76"; 
	useAnisotropic[1] = "1"; 
	materialTag1 = "vehicle";
	castShadows = "1";
	dynamicCubemap = true;
	doubleSided = "1"; 
	translucent = "0"; 
	translucentBlendOp = "None";
	alphaTest = "0"; 
	alphaRef = "1"; 
}; 
singleton Material(material_33_sheriff_famcar_r400_flat_intakemanifold_mpfi_4_highend_rear_c_2144212435_v90_mpfi_injectorplate_rear_flat_mpfi_injectorplate_rear41)
{
	mapTo = "material_33_sheriff_famcar_r400_flat_intakemanifold_mpfi_4_highend_rear_c_2144212435_v90_mpfi_injectorplate_rear_flat_mpfi_injectorplate_rear41"; 
	diffuseMap[0] = "vehicles/common/null.dds";
	specularMap[0] = "camso_col_0xff383838.dds";
	specularPower[0] = "50.000000";
	useAnisotropic[0] = "1"; 
	castShadows = "1"; 
	doubleSided = "1"; 
	diffuseColor[0] = "0.74902 0 0 1"; 
	translucent = "0"; 
	translucentBlendOp = "None";
	alphaTest = "0"; 
	alphaRef = "1"; 
	materialTag0 = "beamng";
}; 
singleton Material(material_34_sheriff_famcar_r400_flat_sohc_2_belt_c_2144165401_v_alternator_v_alternator_modern54)
{
	mapTo = "material_34_sheriff_famcar_r400_flat_sohc_2_belt_c_2144165401_v_alternator_v_alternator_modern54"; 
	diffuseMap[0] = "vehicles/common/null.dds";
	specularMap[0] = "camso_col_0xff383838.dds";
	specularPower[0] = "50.000000";
	useAnisotropic[0] = "1"; 
	castShadows = "1"; 
	doubleSided = "1"; 
	diffuseColor[0] = "1 1 1 1"; 
	normalMap[0] = "camso_alternator_modern_low_m_alternator_modern_normal.dds"; 
	translucent = "0"; 
	translucentBlendOp = "None";
	alphaTest = "0"; 
	alphaRef = "1"; 
	materialTag0 = "beamng";
}; 
singleton Material(material_35_sheriff_famcar_r400_childactor_gen_variable_pulley_dohc_tensionpulley_left_c_cat_2144165399_pulley_component_inl_dohc_4_tensionpulley57)
{
	mapTo = "material_35_sheriff_famcar_r400_childactor_gen_variable_pulley_dohc_tensionpulley_left_c_cat_2144165399_pulley_component_inl_dohc_4_tensionpulley57"; 
	diffuseMap[0] = "vehicles/common/null.dds";
	specularMap[0] = "camso_col_0xff383838.dds";
	specularPower[0] = "50.000000";
	useAnisotropic[0] = "1"; 
	castShadows = "1"; 
	doubleSided = "1"; 
	diffuseColor[0] = "0 0 0 1"; 
	translucent = "0"; 
	translucentBlendOp = "None";
	alphaTest = "0"; 
	alphaRef = "1"; 
	materialTag0 = "beamng";
}; 
singleton Material(material_36_sheriff_famcar_r400_flat_sohc_2_belt_c_2144165401_alt_bracket_boxer_modern_alt_bracket_boxer_modern63)
{
	mapTo = "material_36_sheriff_famcar_r400_flat_sohc_2_belt_c_2144165401_alt_bracket_boxer_modern_alt_bracket_boxer_modern63"; 
	diffuseMap[0] = "vehicles/common/null.dds";
	specularMap[0] = "camso_col_0xff383838.dds";
	specularPower[0] = "50.000000";
	useAnisotropic[0] = "1"; 
	castShadows = "1"; 
	doubleSided = "1"; 
	diffuseColor[0] = "1 1 1 1"; 
	normalMap[0] = "camso_brackets_low_m_alternator_normal.dds"; 
	translucent = "0"; 
	translucentBlendOp = "None";
	alphaTest = "0"; 
	alphaRef = "1"; 
	materialTag0 = "beamng";
}; 
singleton Material(material_37_sheriff_famcar_r400_box6_headers_race_l_c_2144165378_staticmesh_box6_headers_race_l64)
{
	mapTo = "material_37_sheriff_famcar_r400_box6_headers_race_l_c_2144165378_staticmesh_box6_headers_race_l64"; 
	diffuseMap[0] = "vehicles/common/null.dds";
	specularMap[0] = "camso_col_0xff2a3c46.dds";
	specularPower[0] = "800.000000";
	diffuseColor[0] = "1 1 1 1"; 
	normalMap[0] = "camso_weldnormal.dds"; 
	useAnisotropic[0] = "1"; 
	materialTag0 = "beamng";
	castShadows = "1";
	dynamicCubemap = true;
	doubleSided = "1"; 
	translucent = "0"; 
	translucentBlendOp = "None";
	alphaTest = "0"; 
	alphaRef = "1"; 
}; 
singleton Material(material_38_sheriff_famcar_r400_box6_headers_race_l_c_2144165378_staticmesh_box6_headers_race_l64)
{
	mapTo = "material_38_sheriff_famcar_r400_box6_headers_race_l_c_2144165378_staticmesh_box6_headers_race_l64"; 
	diffuseMap[0] = "vehicles/common/null.dds";
	specularMap[0] = "camso_col_0xff383838.dds";
	specularPower[0] = "50.000000";
	useAnisotropic[0] = "1"; 
	castShadows = "1"; 
	doubleSided = "1"; 
	diffuseColor[0] = "0 0 0 1"; 
	translucent = "0"; 
	translucentBlendOp = "None";
	alphaTest = "0"; 
	alphaRef = "1"; 
	materialTag0 = "beamng";
}; 
singleton Material(material_39_sheriff_famcar_r400_headerflange_mid_c_2144165385_staticmesh_headerflange_mid66)
{
	mapTo = "material_39_sheriff_famcar_r400_headerflange_mid_c_2144165385_staticmesh_headerflange_mid66"; 
	diffuseMap[0] = "vehicles/common/null.dds";
	specularMap[0] = "camso_col_0xff2a3c46.dds";
	specularPower[0] = "800.000000";
	diffuseColor[0] = "1 1 1 1"; 
	useAnisotropic[0] = "1"; 
	materialTag0 = "beamng";
	castShadows = "1";
	dynamicCubemap = true;
	doubleSided = "1"; 
	translucent = "0"; 
	translucentBlendOp = "None";
	alphaTest = "0"; 
	alphaRef = "1"; 
}; 
singleton Material(material_40_sheriff_famcar_r400_flat_dohc_4_5_frontcover_c_2144212403_staticmesh_flat_dohc_4_5_frontcover72)
{
	mapTo = "material_40_sheriff_famcar_r400_flat_dohc_4_5_frontcover_c_2144212403_staticmesh_flat_dohc_4_5_frontcover72"; 
	diffuseMap[0] = "vehicles/common/null.dds";
	specularMap[0] = "camso_col_0xff383838.dds";
	specularPower[0] = "50.000000";
	useAnisotropic[0] = "1"; 
	castShadows = "1"; 
	doubleSided = "1"; 
	diffuseColor[0] = "0 0 0 1"; 
	normalMap[0] = "camso_alunormal.dds"; 
	translucent = "0"; 
	translucentBlendOp = "None";
	alphaTest = "0"; 
	alphaRef = "1"; 
	materialTag0 = "beamng";
}; 
singleton Material(material_41_sheriff_famcar_r400_flat_block_mid_actor_c_2144165044_sectionmesh_flat_block_middle130)
{
	mapTo = "material_41_sheriff_famcar_r400_flat_block_mid_actor_c_2144165044_sectionmesh_flat_block_middle130"; 
	diffuseMap[0] = "vehicles/common/null.dds";
	specularMap[0] = "camso_col_0xff383838.dds";
	specularPower[0] = "50.000000";
	useAnisotropic[0] = "1"; 
	castShadows = "1"; 
	doubleSided = "1"; 
	diffuseColor[0] = "1 1 1 1"; 
	translucent = "0"; 
	translucentBlendOp = "None";
	alphaTest = "0"; 
	alphaRef = "1"; 
	materialTag0 = "beamng";
}; 
singleton Material(material_42_sheriff_famcar_r400_flat_block_mid_actor_c_2144165044_sectionmesh_flat_block_middle130)
{
	mapTo = "material_42_sheriff_famcar_r400_flat_block_mid_actor_c_2144165044_sectionmesh_flat_block_middle130"; 
	diffuseMap[0] = "vehicles/common/null.dds";
	specularMap[0] = "camso_col_0xff2a3c46.dds";
	specularPower[0] = "800.000000";
	diffuseColor[0] = "0.737255 0.737255 0.737255 1"; 
	normalMap[0] = "camso_engineblocktophole_01_normal.dds"; 
	useAnisotropic[0] = "1"; 
	materialTag0 = "beamng";
	diffuseMap[1] = "vehicles/common/null.dds";
	specularMap[1] = "camso_col_0xff000000.dds";
	specularPower[1] = "10.000000";
	diffuseColor[1] = "0.737255 0.737255 0.737255 1"; 
	normalMap[1] = "camso_engineblocktophole_01_normal.dds"; 
	useAnisotropic[1] = "1"; 
	materialTag1 = "vehicle";
	castShadows = "1";
	dynamicCubemap = true;
	doubleSided = "1"; 
	translucent = "0"; 
	translucentBlendOp = "None";
	alphaTest = "0"; 
	alphaRef = "1"; 
}; 
singleton Material(material_43_sheriff_famcar_r400_mainexhaustmesh141)
{
	mapTo = "material_43_sheriff_famcar_r400_mainexhaustmesh141"; 
	diffuseMap[0] = "vehicles/common/null.dds";
	specularMap[0] = "camso_col_0xff2a3c46.dds";
	specularPower[0] = "800.000000";
	diffuseColor[0] = "1 1 1 1"; 
	useAnisotropic[0] = "1"; 
	materialTag0 = "beamng";
	castShadows = "1";
	dynamicCubemap = true;
	doubleSided = "1"; 
	translucent = "0"; 
	translucentBlendOp = "None";
	alphaTest = "0"; 
	alphaRef = "1"; 
}; 
